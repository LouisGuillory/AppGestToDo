package appgesttodo;
import java.util.ArrayList;

public class AppGestToDo {
	

	ArrayList <Tache> taches=new ArrayList<>();
	
	public AppGestToDo() {
		
	}

	
	public void creeUneTache(int id,String nomDeTache, String description) {
		Tache a=new Tache(id,nomDeTache,description);
		taches.add(a);
		
	};
	
	
	
	public void afficheToutesLesTaches() {
		int i;
		for (i=0;i<taches.size();i++) {
				System.out.println(taches.get(i).id+"\t"+taches.get(i).nomDeTache+"\t"+taches.get(i).description+"\t"+taches.get(i).termine);
		}
		System.out.println();
	}
	
	public void terminetache(int i,Boolean termine) {
		int j;
		for (j=0;j<taches.size();j++) {
			if (taches.get(j).id==i)
			taches.get(j).setTermine(termine);
		}
	}
	public void afficheUneTache(int i) {
		int j;
		for (j=0;j<taches.size();j++) {
			if (taches.get(j).id==i) {
				System.out.println(taches.get(i).id+"\t"+taches.get(i).nomDeTache+"\t"+taches.get(i).description+"\t"+taches.get(i).termine);
		
			}
		}
		System.out.println();
	}
	
	public Tache getTache(int i) {
		int j;
		for (j=0;j<taches.size();j++) {
			if (taches.get(j).id==i) {
				return taches.get(j);
			}
		}
		return null;
	}
	
	public void setTache(int i,int id,String nomdetache, String description) {
		int j;
		for (j=0;j<taches.size();j++) {
			if (taches.get(j).id==i)
			taches.get(j).setId(id);
			taches.get(j).setNomDeTache(nomdetache);
			taches.get(j).setDescription(description);
		}
	}
	
	
	
}

