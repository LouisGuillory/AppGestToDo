package appgesttodo;

public class Tache{
	public int id;
	public String nomDeTache;
	public String description;
	public Boolean termine;
	
	public Tache(int id,String nomDeTache, String description){
		this.id=id;
		this.nomDeTache=nomDeTache;
		this.description=description;
		this.termine=false;
		
	};
	
	public int getId() {
		return this.id;
	}
	public String getNomDeTache() {
		return this.nomDeTache;
	}
	public String getDescription() {
		return this.description;
	}
	public Boolean getTermine() {
		return this.termine;
	}
	
	public void setId(int id) {
		this.id=id;
	}
	public void setNomDeTache(String nomDeTache) {
		this.nomDeTache=nomDeTache;
	}
	public void setDescription(String description) {
		this.description=description;
	}
	public void setTermine(Boolean termine) {
		this.termine=termine;
	}
}
