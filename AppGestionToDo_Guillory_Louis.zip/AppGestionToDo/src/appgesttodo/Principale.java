package appgesttodo;
import java.util.Scanner;
public class Principale {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AppGestToDo todo=new AppGestToDo();
		Scanner scan=new Scanner(System.in);
		int k=0;
		
		while (k!=7){
			
			k=0;
			System.out.println("Que souhaitez-vous faire?");
			System.out.println("1.Créer une tache.");
			System.out.println("2.Afficher les taches");
			System.out.println("3.Afficher les taches");
			System.out.println("4.Récupérer une tache");
			System.out.println("5.Modifier une tache");
			System.out.println("6.Terminer une tache");
			System.out.println("7.Quitter");
			System.out.print("Choix:");
			k=scan.nextInt();
			System.out.println();
			
			
			if (k==1){
				System.out.println("id de la tache:");
				int id;
				id=scan.nextInt();
				
			    scan.nextLine();
				
				System.out.println("nom de la tache:");
				String nomtache;
				nomtache=scan.nextLine();
				
				System.out.println("description de la tache");
				
				String description;
				description=scan.nextLine();
				
				
				todo.creeUneTache(id,"<"+nomtache+">","<"+ description+">");
				
			} else if (k==2) {
				todo.afficheToutesLesTaches();
			
			}else if (k==3) {
				System.out.println("id de la tache qu vous voulez afficher:");
				int id;
				id=scan.nextInt();
				todo.afficheUneTache(id);
				
			}else if (k==4) {
				System.out.println("id de la tache qu vous voulez récupérer:");
				int id;
				id=scan.nextInt();
				todo.getTache(id);
				
			}else if (k==5) {
				System.out.println("id de la tache qu vous voulez modifier:");
				int id;
				id=scan.nextInt();
				
				
				System.out.println("id de la tache:");
				
				int idnew;
				idnew=scan.nextInt();
				
			   
				scan.nextLine();
				
				System.out.println("nom de la tache:");
				String nomtache;
				nomtache=scan.nextLine();
				
				System.out.println("description de la tache");
				
				String description;
				description=scan.nextLine();

				todo.setTache(id,idnew,nomtache,description);
				
			}else if (k==6) {
				System.out.println("id de la tache qu vous voulez terminer:");
				int id;
				id=scan.nextInt();
				System.out.println("etat de la tache(true=fait,false=pas fait):");
				String etattache;
				etattache=scan.next();
				Boolean termine=false;
				if (etattache.equals("true")){
					termine=true;
				}
				todo.terminetache(id, termine);
				
			
			}else if (k==7) {
				return;
			}else {

				k=0;
			}
			
			
			
			
			
		}
		scan.close();
	
		
		
		
	}

}
